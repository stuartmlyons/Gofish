#include "card.h"
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "deck.h"
#include "player.h"
using namespace std;



   // enum Suit {spades, hearts, diamonds, clubs};

Card::Card(){//default constructor
   myRank =1;
   mySuit =spades;
}          // default, ace of spades

Card::Card(int rank, Suit s){//parameter constructor
   myRank =rank;
   mySuit= s;
}

string Card::toString() const
{
   string ZUZU;
   ZUZU =rankString(myRank)+suitString(mySuit);
   return ZUZU;
}  // return string version e.g. Ac 4h Js
bool Card::sameSuitAs(const Card& c) const{////
     // true if suit same as c
     if(this->mySuit ==c.mySuit){
        return true;
      } else {
        return false;
      }
}
int  Card::getRank() const
{ return myRank;}  // return rank, 1..13

string Card::suitString(Suit s) const
{
 //  string str;
switch(s)
{
case spades: return "s";

case hearts:return "h";//hearts

case diamonds:return "d";//diamonds

case clubs:return "c";//clubs

   }
} // return "s", "h",...

string Card::rankString(int r) const  // return "A", "2", ..."Q"
{
   string rank;
   if(r==1){
      rank ="A";
   } else if (r==2){
      rank="2";
   } else if(r==3){
      rank ="3";
   } else if (r==4){
      rank ="4";
   } else if (r==5){
      rank ="5";
   } else if (r==6){
      rank ="6";
   } else if (r==7){
      rank ="7";
   } else if (r==8){
      rank ="8";
   } else if (r==9){
      rank ="9";
   } else if (r==10){
      rank ="10";
   } else if (r==11){
      rank ="J";
   } else if (r==12){
      rank ="Q";
   } else if (r==13){
      rank ="K";
   }
   return rank; 
}
bool Card::operator == (const Card& rhs) const
{// ranks are equal
   return (myRank ==rhs.myRank && sameSuitAs(rhs));
}
bool Card::operator != (const Card& rhs) const//  not equal ranks
{
    return (myRank !=rhs.myRank|| sameSuitAs(rhs));
}
ostream& operator<<(ostream&out, const Card &c)
{
  
   out<< c.toString();
   return out;
}
