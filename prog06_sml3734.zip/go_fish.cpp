// EE 312 
// UT EID th27979
// Tatiana Flores
// go_fish.cpp
#include <iostream>    // Provides cout and cin
#include <cstdlib>     // Provides EXIT_SUCCESS
#include "card.h"
#include "player.h"
#include "deck.h"
#include <string>
#include <vector>
#include <fstream>// to output in textfile
using namespace std;

void dealHand(Deck &d, Player &p, int numCards);

bool one_turn(Player &p1, Player &p2, Deck &d, ofstream &outputFile);//this function will be switching players 
// and passing deck and output file

int main()
{
  ofstream outputFile;
  outputFile.open("gofish_results.txt"); 
    int numCards = 7;
    Player p1("Joe");
    Player p2("Jane");

    Deck d;  //create a deck of cards
    d.shuffle();

     dealHand(d, p1, numCards);
     dealHand(d, p2, numCards);

    cout << p1.getName() <<" has : " << p1.showHand() << endl;
    outputFile<< p1.getName() << " has : "<< p1.showHand() <<endl;//echo
    cout << p2.getName() <<" has : " << p2.showHand() << endl;
    outputFile<< p2.getName() <<" has : "<<p2.showHand()<<endl;//echo
 
while(1){ ////this is a switch for two players 
   if(one_turn(p1, p2, d,outputFile))
      return EXIT_SUCCESS;
   if(one_turn(p2,p1, d, outputFile))
      return EXIT_SUCCESS;
     }
   outputFile.close();//closing outputfile
  }
bool one_turn(Player &p1, Player &p2, Deck &d, ofstream &outputFile){ 
   Card c1;
   Card c2;
   Card c3;
   Card c4;
   while(p1.checkHandForPair(c1,c2)){//has pair to book
      cout<<p1.getName()<< " has a pair to book"<<endl;
      outputFile<<p1.getName()<< " has a pair to book"<<endl;//echo
      
      p1.removeCardFromHand(c1);
      p1.removeCardFromHand(c2);
      p1.bookCards(c1, c2);
      if(p1.getBookSize()>=26){
         cout <<p1.getName() << " is a winner!!! " << endl;
         outputFile<<p1.getName() <<" is a winner!!! "<<endl;//echo
         return true;}
      cout <<p1.getName() <<" has now: "<<p1.showHand() <<endl;
      outputFile<<p1.getName()<<" has now: "<<p1.showHand()<<endl;//echo
      cout<< p1.getName() <<"'s book: "<<p1.showBooks() << endl;
      outputFile<<p1.getName()<<"'s book: "<<p1.showBooks()<<endl;//echo   
          }
      cout<<p1.getName() <<" has no pair to book"<< endl;
      outputFile<<p1.getName() <<" has no pair to book"<<endl;//echo
      c3 =p1.chooseCardFromHand();
      cout << p1.getName() <<" asks -Do you have a "<< c3.getRank() << " ?" <<endl;
      outputFile<<p1.getName() <<" asks -Do you have a "<<c3.getRank()<<" ?"<<endl;//echo
      if (p2.sameRankInHand(c3)){
         cout <<p2.getName()<<" says- Yes. I have a " << c3.getRank() << endl;
         outputFile<<p2.getName()<<" says -Yes. I have a "<<c3.getRank()<<endl;//echo
         p1.bookCards(p2.removeCardFromHandRank(c3), c3);
         
         cout<<p1.getName()<<"'s book: "<<p1.showBooks()<<endl;
         outputFile<<p1.getName()<<"'s book: "<<p1.showBooks()<<endl;//echo
         } else{
         cout <<p2.getName()<<" says - Go Fish "<<endl;
         outputFile<<p2.getName()<<" says -Go Fish "<<endl;//echo
         c4=d.dealCard();
         p1.addCard(c4);
        cout << p1.getName() <<" draws "<<c4 <<endl;
        outputFile<<p1.getName()<<" draws "<<c4 <<endl;//echo 
        cout <<p1.getName() <<" has now " <<p1.showHand()<<endl;
        outputFile<<p1.getName()<<" has now " <<p1.showHand()<<endl;//echo 
         }
     return false;
  }
void dealHand(Deck &d, Player &p, int numCards)
{
    for (int i=0; i < numCards; i++)
        p.addCard(d.dealCard());
}



