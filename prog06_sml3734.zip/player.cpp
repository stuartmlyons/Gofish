// EE 312
// Go FISH
// UT EID TH27979
// Tatiana Flores
// file player.cpp

#include "player.h"
#include <iostream>
#include <string>
#include <vector>
#include <cstdio>
#include "deck.h"
#include "card.h"
#include <cstdlib>
#include <fstream>
#include <numeric>
using namespace std;


Player::Player()
{
   myName=""; //default Constructor
}


void Player::addCard(Card c)  //adds a card to the hand
{
   myHand.push_back(c);// vector syntax myvector.push_back(myint);
}
void Player::bookCards(Card c1, Card c2){

   myBook.push_back(c1);
   myBook.push_back(c2);

}   

    //OPTIONAL
    // comment out if you decide to not use it
    //this function will check a players hand for a pair.
    //If a pair is found, it returns true and populates the two variables with the cards tha make 
bool Player::checkHandForBook(Card &c1, Card &c2){}// not used

    //OPTIONAL
    // comment out if you decide to not use it
    //Does the player have a card with the same rank as c in her hand?
bool Player::rankInHand(Card c) const{}//not used

    //uses some strategy to choose one card from the player's
    //hand so they can say "Do you have a 4?"
Card Player::chooseCardFromHand() const 
{
//vctor<Card>::const_iterator i;
   return myHand.front(); //always choses the first card in hand      
}

    //Does the player have the card c in her hand?
bool Player::cardInHand(Card c) const
{
int flag =0;
vector<Card>::const_iterator it;   
for( it =myHand.end(); it!=myHand.begin(); it--){
   if(*it ==c){
     flag = flag + 1;
      } 
      if(flag > 0){
          return true;
       } else{
          return false;
      }
   }  
}
    //Remove the card c from the hand and return it to the caller
Card Player::removeCardFromHand(Card c)
{
   int count;//loop counter
   for(count =0; count<myHand.size(); count++){
      if(myHand[count] ==c){
      myHand.erase(myHand.begin()+count);
      }
   } 
}
Card Player::removeCardFromHandRank(Card c)
{
   int count;
   Card c5;
   for(count =0;count<myHand.size(); count++){
      if(myHand[count].getRank() ==c.getRank()){
   ////  cout<<"!!!!!!!!!"<<myHand[count]<<endl;
      c5= myHand[count];
      myHand.erase(myHand.begin()+count);
      return c5;
      }
   }
}

string Player::showHand() const
{
   string result;
   int i; 

   for(i=0; i<myHand.size(); ++i){
      result=result+myHand[i].toString();
      }
   return result;
}

string Player::showBooks() const
{
   int i; //index -iterator
   string result;
   for(i=0; i<myBook.size();++i){// cout<< *i<<endl; if i const_iterator
      result=result+myBook[i].toString();
   }
   return result;  
}

int Player::getHandSize() const
{return myHand.size();}
      
int Player::getBookSize() const
{return myBook.size();}
    //this function will check a players hand for a pair.
    //If a pair is found, it returns true and populates the two variables with the cards tha make the pair.

bool Player::checkHandForPair(Card &c1, Card &c2)
{
   int i; //index for loop
   int j; //index for loop
   int count=0;
   for (i=0; i<myHand.size(); i++){
       for(j=i+1; j<myHand.size(); j++){
       if(myHand[i].getRank()==myHand[j].getRank()){
          count=count+1;
          c1 =myHand[i];
          c2=myHand[j];}

              }
        }
       if (count>0){
         return true;
         } else{
            return false;}
}
    //Does the player have a card with the same rank as c in her hand?
    //e.g. will return true if the player has a 7d and the parameter is 7c

bool Player::sameRankInHand(Card c) const
{ 
int flag=0; 
         vector<Card>::const_iterator i;
         for(i=myHand.begin(); i!=myHand.end(); ++i){
            if((*i).getRank()==c.getRank()){
            flag=flag+1;
      }
   }
   if(flag>0){
      return true;}
   else {
       return false;}
}


