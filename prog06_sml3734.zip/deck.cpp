#include "deck.h"
#include "card.h"
#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include "player.h"
Deck::Deck()        // pristine, sorted deck
{
   unsigned int currentTime =(unsigned)time(0);
   srand(currentTime);
   int index=0;
   
   for (int rank =1; rank <=13; rank++){
      for (int suit =0; suit<=3; suit++){   ///enum 0,1,2,3
         if(suit==0){
         myCards[index]=Card(rank, Card::spades);
         } else if (suit ==1){
         myCards[index]=Card(rank, Card::hearts);
         } else if (suit==2){
         myCards[index]=Card(rank, Card::diamonds);
         } else {
         myCards[index]=Card(rank, Card::clubs);
         }
         index++;
       }
   }
   myIndex =0;
}

void Deck::shuffle() // shuffle the deck, all 52 cards present
{
   Card temp; //temporary holder for a card
   int indexRandom1 =0;
   int indexRandom2 =0;// random index
// Temp and two random indices will execute algorythm of swap 52 times
   for(int i=0; i<SIZE; i++){
      indexRandom1=(rand()%size());
      indexRandom2 =(rand()%size());
      temp =myCards[myIndex +indexRandom1];
      myCards[myIndex +indexRandom1] =myCards[myIndex+indexRandom2];
      myCards[myIndex +indexRandom2]=temp;
   }
}
Card Deck::dealCard()  // get a card, after 52 are dealt, fail
{
   Card card1;
   if(myIndex<SIZE){// until 52 cards max 
      card1=myCards[myIndex];
      myIndex++; //increment index
      } else{
         cout<< "fail";// reached max 52
      }
      return card1;
}   

int  Deck::size() const // # cards left in the deck
{
   int size =SIZE -myIndex;
      if(size>0){
        return size;
        } else {
          return 0;
        }
}
